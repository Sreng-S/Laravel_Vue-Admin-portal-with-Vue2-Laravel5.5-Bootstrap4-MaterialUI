var base = require('settings/payment-method/update-payment-method-braintree');

Vue.component('spark-update-payment-method-braintree', {
    mixins: [base]
});
