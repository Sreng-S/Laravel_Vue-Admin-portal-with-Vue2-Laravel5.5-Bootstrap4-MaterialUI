var base = require('settings/security');

Vue.component('spark-security', {
    mixins: [base]
});
