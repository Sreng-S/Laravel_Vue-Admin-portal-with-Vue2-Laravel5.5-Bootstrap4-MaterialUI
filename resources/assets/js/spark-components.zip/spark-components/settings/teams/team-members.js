var base = require('settings/teams/team-members');

Vue.component('spark-team-members', {
    mixins: [base]
});
