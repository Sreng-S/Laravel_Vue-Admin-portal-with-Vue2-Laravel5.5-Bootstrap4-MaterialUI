var base = require('settings/api/create-token');

Vue.component('spark-create-token', {
    mixins: [base]
});
