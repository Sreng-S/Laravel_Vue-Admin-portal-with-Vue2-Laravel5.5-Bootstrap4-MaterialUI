var base = require('settings/settings');

Vue.component('spark-settings', {
    mixins: [base]
});
