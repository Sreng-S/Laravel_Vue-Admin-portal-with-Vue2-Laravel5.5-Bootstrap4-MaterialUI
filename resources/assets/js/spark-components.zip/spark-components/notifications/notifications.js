var base = require('notifications/notifications');

Vue.component('spark-notifications', {
    mixins: [base]
});
